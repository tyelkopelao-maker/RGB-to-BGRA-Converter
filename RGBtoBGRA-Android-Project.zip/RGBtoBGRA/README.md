# RGB to BGRA Texture Converter

Aplicación Android nativa en Kotlin + Jetpack Compose. Diseñada para Android 13 o superior (minSdk 33), con procesamiento local y sin permiso general de almacenamiento.

## Funciones incluidas

- Selección de PNG, JPG/JPEG y WebP mediante Storage Access Framework.
- Decodificación local con Android `ImageDecoder`.
- Vista previa original y convertida.
- Intercambio exacto de los canales R y B; G y A permanecen intactos.
- Exportación PNG sin pérdida, manteniendo dimensiones y alpha.
- Exportación BMP con `BITMAPV4HEADER` (108 bytes), 32 bpp, `BI_BITFIELDS`, máscaras explícitas R/G/B/A y píxeles serializados en orden BGRA little-endian.
- Selector de destino del sistema, nombre automático, compartir último archivo e historial local de ocho exportaciones.
- Sin INTERNET permission, cuentas, publicidad ni servicios remotos.

## Abrir y compilar

1. Instalar Android Studio (versión compatible con Android Gradle Plugin 8.6.1) y el Android SDK Platform 35.
2. Abrir esta carpeta (`RGBtoBGRA`) en Android Studio.
3. Esperar la sincronización de Gradle. Se requiere JDK 17 y Gradle 8.7.
4. Conectar un teléfono Android 13+ con depuración USB o crear un emulador.
5. Ejecutar **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio dejará el APK debug en `app/build/outputs/apk/debug/app-debug.apk`.

También se puede compilar desde una terminal con Gradle 8.7 instalado:

```bash
gradle assembleDebug
```

## Validación del BMP

Ejecutar:

```bash
python3 tests/verify_bmp_format.py
```

La prueba de referencia comprueba la firma BMP, tamaño de archivo, tamaño de BITMAPV4HEADER, altura top-down, 32 bits por píxel, `BI_BITFIELDS`, las cuatro máscaras y bytes BGRA con alpha.

## Límites de validación de esta entrega

El entorno donde se preparó este proyecto no tiene Android SDK ni Gradle instalados y no dispone de un dispositivo Android conectado. Por eso no se afirma que el APK haya sido compilado, instalado o probado en un Galaxy S20 FE. El proyecto fuente está preparado para abrirse y compilarse en Android Studio; la prueba incluida verifica la estructura binaria BMP de referencia, no sustituye una prueba de integración en Android.
