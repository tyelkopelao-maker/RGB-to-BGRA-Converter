"""Reference-format test for the BMP writer contract used by ImageConverter.kt.
Run with: python3 tests/verify_bmp_format.py
"""
import struct

# Two source pixels in Android ARGB integer representation.
src = [0x80402010, 0x00ABCDEF]
width, height = 2, 1
pixels = bytearray()
for p in src:
    r, g, b, a = (p >> 16) & 255, (p >> 8) & 255, p & 255, (p >> 24) & 255
    # R/B exchange, then serialize output as BGRA bytes.
    pixels += bytes((r, g, b, a))

image_size = width * height * 4
header = bytearray()
header += b'BM'
header += struct.pack('<IHHI', 14 + 108 + image_size, 0, 0, 14 + 108)
header += struct.pack('<IiiHHIIiiII', 108, width, -height, 1, 32, 3, image_size, 2835, 2835, 0, 0)
header += struct.pack('<IIII', 0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
header += struct.pack('<I', 0x73524742)
header += struct.pack('<9I', *([0] * 9))
header += struct.pack('<3I', 0, 0, 0)
blob = bytes(header + pixels)

assert len(header) == 122, len(header)
assert blob[:2] == b'BM'
assert struct.unpack_from('<I', blob, 2)[0] == len(blob)
assert struct.unpack_from('<I', blob, 14)[0] == 108
assert struct.unpack_from('<i', blob, 22)[0] == -1
assert struct.unpack_from('<H', blob, 28)[0] == 32
assert struct.unpack_from('<I', blob, 30)[0] == 3
assert struct.unpack_from('<4I', blob, 54) == (0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000)
assert blob[122:126] == bytes((0x40, 0x20, 0x10, 0x80))  # B_out,G,R_out,A
assert blob[126:130] == bytes((0xAB, 0xCD, 0xEF, 0x00))
print('PASS: BMP V4 header, 32 bpp, BI_BITFIELDS masks, BGRA bytes and alpha verified.')
