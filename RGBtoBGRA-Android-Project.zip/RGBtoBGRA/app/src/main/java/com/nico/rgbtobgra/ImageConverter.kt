package com.nico.rgbtobgra

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.OutputStream

object ImageConverter {
    fun decode(resolver: ContentResolver, uri: Uri): Bitmap {
        val source = ImageDecoder.createSource(resolver, uri)
        val decoded = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.isMutableRequired = false
        }
        return if (decoded.config == Bitmap.Config.ARGB_8888) decoded
        else decoded.copy(Bitmap.Config.ARGB_8888, false)
            ?: error("No se pudo convertir la imagen a ARGB_8888")
    }

    /** Returns a new ARGB_8888 bitmap with R and B exchanged. Alpha and green are untouched. */
    fun swapRedBlue(input: Bitmap): Bitmap {
        val width = input.width
        val height = input.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val sourceRow = IntArray(width)
        val outputRow = IntArray(width)
        for (y in 0 until height) {
            input.getPixels(sourceRow, 0, width, 0, y, width, 1)
            for (x in 0 until width) {
                val p = sourceRow[x]
                val a = p ushr 24 and 0xFF
                val r = p ushr 16 and 0xFF
                val g = p ushr 8 and 0xFF
                val b = p and 0xFF
                outputRow[x] = (a shl 24) or (b shl 16) or (g shl 8) or r
            }
            output.setPixels(outputRow, 0, width, 0, y, width, 1)
        }
        return output
    }

    fun writePng(bitmap: Bitmap, output: OutputStream) {
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) { "No se pudo codificar el PNG" }
        output.flush()
    }

    /** Writes a Windows BMP with a 108-byte BITMAPV4HEADER and explicit RGBA masks.
     * Pixel bytes are little-endian BGRA. Negative height marks top-down rows.
     */
    fun writeBmpBgra32(bitmap: Bitmap, output: OutputStream) {
        val width = bitmap.width
        val height = bitmap.height
        val imageBytesLong = width.toLong() * height.toLong() * 4L
        require(imageBytesLong <= Int.MAX_VALUE - 122L) { "La imagen es demasiado grande para un BMP clásico" }
        val imageBytes = imageBytesLong.toInt()
        val fileSize = 14 + 108 + imageBytes
        val out = DataOutputStream(BufferedOutputStream(output))

        // BITMAPFILEHEADER (14 bytes)
        out.writeByte('B'.code); out.writeByte('M'.code)
        out.writeIntLE(fileSize)
        out.writeShortLE(0); out.writeShortLE(0)
        out.writeIntLE(14 + 108)

        // BITMAPV4HEADER (108 bytes)
        out.writeIntLE(108)
        out.writeIntLE(width)
        out.writeIntLE(-height) // top-down: first row is the top row
        out.writeShortLE(1) // planes
        out.writeShortLE(32) // bits per pixel
        out.writeIntLE(3) // BI_BITFIELDS
        out.writeIntLE(imageBytes)
        out.writeIntLE(2835); out.writeIntLE(2835) // ~72 DPI
        out.writeIntLE(0); out.writeIntLE(0) // palette counts
        out.writeIntLE(0x00FF0000) // red mask
        out.writeIntLE(0x0000FF00) // green mask
        out.writeIntLE(0x000000FF) // blue mask
        out.writeIntLE(0xFF000000.toInt()) // alpha mask
        out.writeIntLE(0x73524742) // LCS_sRGB
        repeat(9) { out.writeIntLE(0) } // CIEXYZTRIPLE endpoints
        out.writeIntLE(0); out.writeIntLE(0); out.writeIntLE(0) // gamma

        val row = IntArray(width)
        val bytes = ByteArray(width * 4)
        for (y in 0 until height) {
            bitmap.getPixels(row, 0, width, 0, y, width, 1)
            var j = 0
            for (p in row) {
                val r = p ushr 16 and 0xFF
                val g = p ushr 8 and 0xFF
                val b = p and 0xFF
                val a = p ushr 24 and 0xFF
                // Input bitmap is the original: write the channel-swapped output as BGRA.
                bytes[j++] = r.toByte() // B_out = R_in
                bytes[j++] = g.toByte()
                bytes[j++] = b.toByte() // R_out = B_in
                bytes[j++] = a.toByte()
            }
            out.write(bytes)
        }
        out.flush()
    }

    private fun DataOutputStream.writeIntLE(value: Int) {
        writeByte(value and 0xFF); writeByte(value ushr 8 and 0xFF)
        writeByte(value ushr 16 and 0xFF); writeByte(value ushr 24 and 0xFF)
    }
    private fun DataOutputStream.writeShortLE(value: Int) {
        writeByte(value and 0xFF); writeByte(value ushr 8 and 0xFF)
    }
}
