package com.nico.rgbtobgra

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

private val Navy = Color(0xFF07152E)
private val Panel = Color(0xFF102544)
private val Yellow = Color(0xFFFFD21F)
private val Muted = Color(0xFFB9C7D9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppScreen() }
    }

    @Composable
    private fun AppScreen() {
        var original by remember { mutableStateOf<Bitmap?>(null) }
        var converted by remember { mutableStateOf<Bitmap?>(null) }
        var imageName by remember { mutableStateOf("") }
        var inputMime by remember { mutableStateOf("image/desconocido") }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Seleccioná una textura para comenzar.") }
        var lastSavedUri by remember { mutableStateOf<Uri?>(null) }
        var history by remember { mutableStateOf(loadHistory()) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                busy = true
                converted = null
                status = "Cargando imagen…"
                lifecycleScope.launch {
                    try {
                        val loaded = withContext(Dispatchers.IO) { ImageConverter.decode(contentResolver, uri) }
                        original = loaded
                        imageName = queryDisplayName(uri) ?: "textura"
                        inputMime = contentResolver.getType(uri) ?: "formato desconocido"
                        status = "Imagen cargada. Presioná CONVERTIR."
                    } catch (e: Exception) {
                        status = "No se pudo abrir la imagen: ${e.localizedMessage ?: "formato no válido"}"
                    } finally { busy = false }
                }
            }
        }
        var pendingFormat by remember { mutableStateOf("png") }
        val pngSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
            if (uri != null) saveToUri(uri, "png", original, converted, onDone = { saved, message ->
                lastSavedUri = if (saved) uri else null
                status = message
                if (saved) { history = addHistory("${imageName.substringBeforeLast('.', imageName)}_RGBtoBGRA.png") }
            })
        }
        val bmpSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/bmp")) { uri ->
            if (uri != null) saveToUri(uri, "bmp", original, converted, onDone = { saved, message ->
                lastSavedUri = if (saved) uri else null
                status = message
                if (saved) { history = addHistory("${imageName.substringBeforeLast('.', imageName)}_BGRA32.bmp") }
            })
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Yellow, onPrimary = Navy, background = Navy, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, secondary = Yellow
        )) {
            Surface(Modifier.fillMaxSize(), color = Navy) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column {
                        Text("RGB TO BGRA", color = Yellow, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
                        Text("TEXTURE CONVERTER", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("FIFA 16 MOBILE · CONVERSIÓN LOCAL", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    }
                    Button(onClick = { picker.launch(arrayOf("image/png", "image/jpeg", "image/webp", "image/*")) }, modifier = Modifier.fillMaxWidth().height(56.dp), enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Navy), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(9.dp))
                        Text("SELECCIONAR IMAGEN", fontWeight = FontWeight.ExtraBold)
                    }

                    if (original != null) {
                        Text("ARCHIVO: $imageName", color = Muted, fontSize = 12.sp, maxLines = 2)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PreviewCard("ORIGINAL", original!!, Modifier.weight(1f))
                            PreviewCard("R/B INTERCAMBIADOS", converted, Modifier.weight(1f))
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("INFORMACIÓN", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("Resolución: ${original!!.width} × ${original!!.height}", color = Color.White, fontSize = 13.sp)
                                Text("Formato: $inputMime · decodificado a ARGB_8888", color = Muted, fontSize = 12.sp)
                                Text("Alpha: ${if (original!!.hasAlpha()) "disponible" else "sin transparencia"}", color = Muted, fontSize = 12.sp)
                                Text("Salida: R ↔ B · G y A intactos", color = Muted, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                            Box(Modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) {
                                Text("La vista previa aparecerá acá", color = Muted, textAlign = TextAlign.Center)
                            }
                        }
                    }

                    Button(onClick = {
                        val src = original ?: return@Button
                        busy = true; status = "Convirtiendo canales…"
                        lifecycleScope.launch {
                            try {
                                converted = withContext(Dispatchers.Default) { ImageConverter.swapRedBlue(src) }
                                status = "Conversión terminada. Canales R/B intercambiados."
                            } catch (e: OutOfMemoryError) {
                                status = "Memoria insuficiente para procesar esta imagen. Probá una textura más pequeña."
                            } catch (e: Exception) {
                                status = "Error al convertir: ${e.localizedMessage}"
                            } finally { busy = false }
                        }
                    }, enabled = original != null && !busy, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Navy), shape = RoundedCornerShape(12.dp)) {
                        if (busy) CircularProgressIndicator(Modifier.size(19.dp), color = Navy, strokeWidth = 2.dp)
                        else Text("CONVERTIR", fontWeight = FontWeight.ExtraBold)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = {
                            val base = imageName.substringBeforeLast('.', imageName).ifBlank { "texture" }
                            pngSaver.launch("${base}_RGBtoBGRA.png")
                        }, enabled = converted != null && !busy, modifier = Modifier.weight(1f).height(54.dp), border = BorderStroke(1.dp, Yellow), shape = RoundedCornerShape(12.dp)) {
                            Text("GUARDAR PNG", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = {
                            val base = imageName.substringBeforeLast('.', imageName).ifBlank { "texture" }
                            bmpSaver.launch("${base}_BGRA32.bmp")
                        }, enabled = original != null && converted != null && !busy, modifier = Modifier.weight(1f).height(54.dp), border = BorderStroke(1.dp, Yellow), shape = RoundedCornerShape(12.dp)) {
                            Text("BMP BGRA 32", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                    if (lastSavedUri != null) {
                        OutlinedButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = contentResolver.getType(lastSavedUri!!) ?: "application/octet-stream"
                                putExtra(Intent.EXTRA_STREAM, lastSavedUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            startActivity(Intent.createChooser(send, "Compartir textura"))
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("COMPARTIR ÚLTIMO ARCHIVO")
                        }
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("ESTADO", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!busy && status.contains("terminada") || status.contains("guardado")) Icon(Icons.Default.CheckCircle, null, tint = Yellow, modifier = Modifier.size(17.dp))
                                Text(status, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
                            }
                            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Yellow, trackColor = Navy)
                        }
                    }
                    if (history.isNotEmpty()) {
                        Text("ÚLTIMAS CONVERSIONES", color = Yellow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        history.forEach { Text("•  $it", color = Muted, fontSize = 11.sp, maxLines = 1) }
                    }
                    Text("100% OFFLINE · SIN CUENTAS · SIN PUBLICIDAD", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
                }
            }
        }
    }

    @Composable
    private fun PreviewCard(label: String, bitmap: Bitmap?, modifier: Modifier = Modifier) {
        Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(label, color = Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0xFF26374B), RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
                    if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else Text("Pendiente", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }

    private fun saveToUri(uri: Uri, format: String, original: Bitmap?, converted: Bitmap?, onDone: (Boolean, String) -> Unit) {
        if (original == null || converted == null) { onDone(false, "Primero seleccioná y convertí una imagen."); return }
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri, "w")?.use { out ->
                        if (format == "png") ImageConverter.writePng(converted, out)
                        else ImageConverter.writeBmpBgra32(original, out)
                    } ?: error("No se pudo abrir el destino")
                }
                onDone(true, if (format == "png") "PNG corregido guardado correctamente." else "BMP BGRA de 32 bits guardado correctamente.")
            } catch (e: Exception) {
                onDone(false, "No se pudo guardar: ${e.localizedMessage ?: "error de escritura"}")
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun loadHistory(): List<String> = getSharedPreferences("history", MODE_PRIVATE).getString("items", "")!!
        .split("\n").filter { it.isNotBlank() }.take(8)

    private fun addHistory(item: String): List<String> {
        val updated = (listOf(item) + loadHistory().filterNot { it == item }).take(8)
        getSharedPreferences("history", MODE_PRIVATE).edit().putString("items", updated.joinToString("\n")).apply()
        return updated
    }
}
